<script>
</script>

<div class=" box px-4 py-2">
	<p class="text">Revenue</p>
	<p class="text-percentage text-end">+1,8%</p>
	<p class="text-currency">123.456,78 €</p>
</div>

<style>
	@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap');
	.box {
		max-width: 424px;
		max-height: 140px;
		border-radius: 20px;
		background: var(--test-bg, #242940);
	}

	.text {
		color: #fff;
		font-family: Nunito;
		font-size: 28px;
		font-style: normal;
		font-weight: 200;
		line-height: normal;
		letter-spacing: 2.24px;
	}
	.text-percentage {
		color: #19dc2c;
		font-size: 18px;
		font-family: 'Nunito', sans-serif;
		font-weight: 200;
		letter-spacing: 1.44px;
	}
	.text-currency {
		color: #fff;
		font-family: Nunito;
		font-size: 40px;
		font-style: normal;
		font-weight: 400;
		line-height: normal;
		letter-spacing: 3.2px;
	}
</style>
